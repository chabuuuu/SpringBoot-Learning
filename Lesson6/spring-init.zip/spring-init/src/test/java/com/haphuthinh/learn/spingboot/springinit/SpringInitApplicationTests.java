package com.haphuthinh.learn.spingboot.springinit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringInitApplicationTests {

	@Test
	void contextLoads() {
	}

}
